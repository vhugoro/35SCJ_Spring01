package br.com.fiap.cervejariabatchtasklet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CervejariaBatchTaskletApplication {

	public static void main(String[] args) {
		SpringApplication.run(CervejariaBatchTaskletApplication.class, args);
	}

}
