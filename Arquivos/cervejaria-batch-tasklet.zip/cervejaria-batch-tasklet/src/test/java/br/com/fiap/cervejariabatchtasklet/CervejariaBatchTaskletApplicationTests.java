package br.com.fiap.cervejariabatchtasklet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CervejariaBatchTaskletApplicationTests {

	@Test
	void contextLoads() {
	}

}
